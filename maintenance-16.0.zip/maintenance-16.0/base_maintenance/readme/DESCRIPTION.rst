This module extends the functionality of Odoo Maintenance module to add
some basic features that are standard in other Odoo apps:

* Team leader in maintenance team.
* Description field in maintenance team.
* Creates the unexisting search view for maintenance team.
* Empty button box on maintenance request to be extended by other modules.
* Maintenance Request Report
